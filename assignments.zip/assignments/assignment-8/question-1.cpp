#include<iostream>
using namespace std;


class Distance {
    int feet;
    int inches;

    public:
        Distance operator + (const Distance &d){
            
        }
        // Distance operator ++
};

int main(){

    return 0;
}